package com.example.demo1;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class HelloController {

    @FXML
    private TableView<User> table;
    @FXML
    private TableColumn<User, String> nameCol;
    @FXML
    private TableColumn<User, String> emailCol;
    @FXML
    private TableColumn<User, String> platformCol;
    @FXML
    private TableColumn<User, String> adminCol;
    @FXML
    private TableColumn<User, String> versionCol;
    @FXML
    private TableColumn<User, String> createdCol;

    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField platformField;
    @FXML
    private CheckBox adminCheckBox;
    @FXML
    private Spinner<Integer> versionSpinner;

    private final ObservableList<User> userData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        nameCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getName()));
        emailCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEmail()));
        platformCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPlatform()));
        adminCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().isAdmin() ? "Yes" : "No"));
        versionCol.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().getVersion())));
        createdCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCreatedAt()));

        table.setItems(userData);
    }

    @FXML
    private void handleAddUser() {
        String name = nameField.getText();
        String email = emailField.getText();
        String platform = platformField.getText();
        boolean isAdmin = adminCheckBox.isSelected();
        int version = versionSpinner.getValue();
        String createdAt = java.time.LocalDate.now().toString();

        User newUser = new User(name, email, platform, isAdmin, version, createdAt);
        userData.add(newUser);

        nameField.clear();
        emailField.clear();
        platformField.clear();
        adminCheckBox.setSelected(false);
        versionSpinner.getValueFactory().setValue(1);
    }

    @FXML
    private void handleClearTable() {
        userData.clear();
    }

    @FXML
    private void handleDeleteUser() {
        User selectedUser = table.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            userData.remove(selectedUser);
        }
    }
}
