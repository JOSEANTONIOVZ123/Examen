package com.example.demo1;

public class User {
    public User(String name, String email, String platform, boolean isAdmin, int version, String createdAt) {
    }

    public String getName() {
        return getName();
    }

    public String getEmail() {
        return getEmail();
    }

    public String getPlatform() {
        return getPlatform();
    }

    public boolean isAdmin() {
        return true;
    }

    public char[] getVersion() {
        return getVersion();
    }

    public String getCreatedAt() {
        return getCreatedAt();
    }
}
